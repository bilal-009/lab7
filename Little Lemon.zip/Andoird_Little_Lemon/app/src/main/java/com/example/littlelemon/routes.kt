package com.example.littlelemon

object Routes {
    const val LoginScreen = "login"
    const val HomeScreen = "home"
}
